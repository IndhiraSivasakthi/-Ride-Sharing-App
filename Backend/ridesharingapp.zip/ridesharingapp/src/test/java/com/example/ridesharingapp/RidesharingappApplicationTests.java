package com.example.ridesharingapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RidesharingappApplicationTests {

	@Test
	void contextLoads() {
	}

}
