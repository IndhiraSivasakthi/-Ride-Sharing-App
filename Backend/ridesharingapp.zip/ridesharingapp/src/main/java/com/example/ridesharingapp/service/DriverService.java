package com.example.ridesharingapp.service;

import com.example.ridesharingapp.model.Driver;
import com.example.ridesharingapp.model.Vehicle;
import com.example.ridesharingapp.repository.DriverRepository;
import com.example.ridesharingapp.repository.VehicleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DriverService {

    @Autowired
    private DriverRepository driverRepository;

    @Autowired
    private VehicleRepository vehicleRepository;

    public Driver registerDriver(Driver driver, Vehicle vehicle) {
        driver.setVehicle(vehicle);
        vehicle.setDriver(driver);
        return driverRepository.save(driver);
    }

    public Driver findDriverByUsername(String username) {
        return driverRepository.findByUsername(username).orElse(null);
    }
}
