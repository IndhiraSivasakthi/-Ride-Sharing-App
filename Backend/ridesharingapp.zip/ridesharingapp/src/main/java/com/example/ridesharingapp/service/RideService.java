package com.example.ridesharingapp.service;

import com.example.ridesharingapp.model.Ride;
import com.example.ridesharingapp.model.User;
import com.example.ridesharingapp.repository.RideRepository;
import com.example.ridesharingapp.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.Date;
import java.util.List;
import java.util.Optional;
import java.util.logging.Level;
import java.util.logging.Logger;

@Service
public class RideService {

    private static final Logger LOGGER = Logger.getLogger(RideService.class.getName());

    @Autowired
    private RideRepository rideRepository;

    @Autowired
    private UserRepository userRepository;

    public List<Ride> getRidesByUsername(String username) {
        return rideRepository.findByUsername(username);
    }

    public List<Ride> getRidesByDate(Date rideDate) {
        return rideRepository.findByRideDate(rideDate);
    }

    public Ride bookRide(Ride ride, String username) {
        Optional<User> userOptional = userRepository.findByUsername(username);
        if (userOptional.isPresent()) {
            User user = userOptional.get();
            ride.setUser(user);
            ride.setStatus("Booked");
            ride.setUsername(user.getUsername()); // Set username from user
            return rideRepository.save(ride);
        } else {
            LOGGER.log(Level.WARNING, "User not found for username: " + username);
            throw new RuntimeException("User not found");
        }
    }

    public boolean cancelRide(Long rideId) {
        if (rideRepository.existsById(rideId)) {
            rideRepository.deleteById(rideId);
            return true;
        }
        LOGGER.log(Level.WARNING, "Ride not found for id: " + rideId);
        return false;
    }

    public List<Ride> getBookedRides() {
        return rideRepository.findByStatus("Booked");
    }

    public boolean acceptRideRequest(Long rideId) {
        Optional<Ride> optionalRide = rideRepository.findById(rideId);
        if (optionalRide.isPresent()) {
            Ride ride = optionalRide.get();
            ride.setStatus("Accepted");
            rideRepository.save(ride);
            return true;
        }
        return false;
    }

    public boolean rejectRideRequest(Long rideId) {
        Optional<Ride> optionalRide = rideRepository.findById(rideId);
        if (optionalRide.isPresent()) {
            Ride ride = optionalRide.get();
            ride.setStatus("Rejected");
            rideRepository.save(ride);
            return true;
        }
        return false;
    }


    public List<Ride> getPendingRides() {
        return rideRepository.findByStatus("Pending");
    }

   
}
