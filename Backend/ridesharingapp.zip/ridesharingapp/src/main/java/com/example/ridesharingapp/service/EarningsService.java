package com.example.ridesharingapp.service;

public class EarningsService {

}
