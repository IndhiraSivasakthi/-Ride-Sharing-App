package com.example.ridesharingapp.repository;

import com.example.ridesharingapp.model.RideFeedback;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FeedbackRepository extends JpaRepository<RideFeedback, Long> {
}
