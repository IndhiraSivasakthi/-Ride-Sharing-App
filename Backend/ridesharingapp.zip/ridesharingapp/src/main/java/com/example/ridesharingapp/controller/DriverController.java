package com.example.ridesharingapp.controller;

import com.example.ridesharingapp.model.Driver;
import com.example.ridesharingapp.model.Vehicle;
import com.example.ridesharingapp.service.DriverService;
import com.example.ridesharingapp.repository.DriverRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Optional;

@RestController
@RequestMapping("/api")
public class DriverController {

    @Autowired
    private DriverService driverService;

    @Autowired
    private DriverRepository driverRepository;

    private static final String PROFILE_PICTURES_DIR = "/ridesharingapp/Profile_picture";

    @PostMapping("/register")
    public Driver registerDriver(@RequestParam("fullName") String fullName,
                                 @RequestParam("email") String email,
                                 @RequestParam("phoneNumber") String phoneNumber,
                                 @RequestParam("profilePicture") MultipartFile profilePicture,
                                 @RequestParam("username") String username,
                                 @RequestParam("password") String password,
                                 @RequestParam("dateOfBirth") String dateOfBirth,
                                 @RequestParam("gender") String gender,
                                 @RequestParam("driversLicense") String driversLicense,
                                 @RequestParam("vehicleMake") String vehicleMake,
                                 @RequestParam("vehicleModel") String vehicleModel,
                                 @RequestParam("vehicleYear") int vehicleYear,
                                 @RequestParam("vehicleColor") String vehicleColor,
                                 @RequestParam("licensePlate") String licensePlate,
                                 @RequestParam("insuranceInfo") String insuranceInfo,
                                 @RequestParam("drivingExperience") int drivingExperience) throws IOException {

        // Ensure profile pictures directory exists
        Path profilePicturesDirPath = Paths.get(PROFILE_PICTURES_DIR);
        if (!Files.exists(profilePicturesDirPath)) {
            Files.createDirectories(profilePicturesDirPath);
        }

        // Save profile picture to the file system
        String profilePicturePath = PROFILE_PICTURES_DIR + "/" + profilePicture.getOriginalFilename();
        Files.copy(profilePicture.getInputStream(), Paths.get(profilePicturePath));

        // Create Driver and Vehicle objects
        Driver driver = new Driver();
        driver.setFullName(fullName);
        driver.setEmail(email);
        driver.setPhoneNumber(phoneNumber);
        driver.setProfilePicture(profilePicturePath);
        driver.setUsername(username);
        driver.setPassword(password);
        driver.setDateOfBirth(java.sql.Date.valueOf(dateOfBirth));
        driver.setGender(gender);
        driver.setDriversLicense(driversLicense);

        Vehicle vehicle = new Vehicle();
        vehicle.setVehicleMake(vehicleMake);
        vehicle.setVehicleModel(vehicleModel);
        vehicle.setVehicleYear(vehicleYear);
        vehicle.setVehicleColor(vehicleColor);
        vehicle.setLicensePlate(licensePlate);
        vehicle.setInsuranceInfo(insuranceInfo);
        vehicle.setDrivingExperience(drivingExperience);

        // Register driver
        return driverService.registerDriver(driver, vehicle);
    }

    @PostMapping("/signin")
    public boolean loginDriver(@RequestBody Driver loginDriver) {
        Optional<Driver> driver = driverRepository.findByUsername(loginDriver.getUsername());
        if (driver.isPresent() && driver.get().getPassword().equals(loginDriver.getPassword())) {
            return true;
        } else {
            return false;
        }
    }
    @GetMapping("/search")
    public ResponseEntity<Driver> searchDriver(@RequestParam String username) {
        Driver driver = driverService.findDriverByUsername(username);
        if (driver != null) {
            return ResponseEntity.ok(driver);
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
