package com.example.ridesharingapp.controller;

public class EarningsController {

}
