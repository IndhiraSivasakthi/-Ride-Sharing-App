package com.example.ridesharingapp.service;

import com.example.ridesharingapp.model.RideFeedback;
import com.example.ridesharingapp.repository.FeedbackRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FeedbackService {

    @Autowired
    private FeedbackRepository rideFeedbackRepository;

    public boolean submitFeedback(int rating, String feedback) {
        RideFeedback rideFeedback = new RideFeedback();
        rideFeedback.setRating(rating);
        rideFeedback.setFeedback(feedback);

        try {
            rideFeedbackRepository.save(rideFeedback);
            return true;
        } catch (Exception e) {
            // Handle exception (e.g., log error)
            return false;
        }
    }
}
