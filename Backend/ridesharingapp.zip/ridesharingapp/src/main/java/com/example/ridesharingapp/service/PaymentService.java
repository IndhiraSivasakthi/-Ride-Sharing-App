package com.example.ridesharingapp.service;

import com.example.ridesharingapp.model.Payment;
import com.example.ridesharingapp.model.Ride;
import com.example.ridesharingapp.repository.PaymentRepository;
import com.example.ridesharingapp.repository.RideRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PaymentService {

    @Autowired
    private PaymentRepository paymentRepository;

    @Autowired
    private RideRepository rideRepository;

    public boolean processPayment(Long rideId, Double amount, String paymentMethod) {
        Ride ride = rideRepository.findById(rideId).orElse(null);
        if (ride == null) {
            return false; // Ride not found
        }

        Payment payment = new Payment();
        payment.setRide(ride);
        payment.setAmount(amount);
        payment.setPaymentMethod(paymentMethod);
        payment.setPaymentStatus("Completed"); // Or other statuses as needed

        paymentRepository.save(payment);
        return true; // Payment processed successfully
    }
}
