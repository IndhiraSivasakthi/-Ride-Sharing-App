package com.example.ridesharingapp.repository;

import com.example.ridesharingapp.model.Ride;
import org.springframework.data.jpa.repository.JpaRepository;

import java.sql.Date;
import java.util.List;

public interface RideRepository extends JpaRepository<Ride, Long> {
    List<Ride> findByUsername(String username);
    List<Ride> findByRideDate(Date rideDate);
    List<Ride> findByStatus(String status);
    
    
}
