package com.example.ridesharingapp.dto;

public class RideRequestDTO {
    private Long rideId;
    private Long driverId;
	public Long getRideId() {
		return rideId;
	}
	public void setRideId(Long rideId) {
		this.rideId = rideId;
	}
	public Long getDriverId() {
		return driverId;
	}
	public void setDriverId(Long driverId) {
		this.driverId = driverId;
	}

   
}
