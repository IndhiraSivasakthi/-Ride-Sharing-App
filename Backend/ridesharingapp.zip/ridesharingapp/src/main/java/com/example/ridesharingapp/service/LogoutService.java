package com.example.ridesharingapp.service;

import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class LogoutService {

    // This is where you would handle the logic to record logout details, e.g., save to database

    public boolean recordLogout(String username, LocalDateTime logoutTime) {
        // Implement your logic to record the logout time and username
        // For example, save it to a database
        System.out.println("User: " + username + " logged out at: " + logoutTime);
        return true;  // Return true if successful
    }
}
