package com.example.ridesharingapp.controller;

import com.example.ridesharingapp.model.Ride;
import com.example.ridesharingapp.service.RideService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.example.ridesharingapp.dto.RideRequestDTO;

import java.sql.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class RideController {

    @Autowired
    private RideService rideService;

    @GetMapping("/allrides")
    public List<Ride> getAllRides() {
        return rideService.getBookedRides(); // Fetch only booked rides
    }

    @PostMapping("/riderequests/accept")
    public ResponseEntity<?> acceptRideRequest(@RequestBody RideRequestDTO rideRequestDTO) {
        boolean success = rideService.acceptRideRequest(rideRequestDTO.getRideId());
        if (success) {
            return ResponseEntity.ok().body("{\"success\": true}");
        } else {
            return ResponseEntity.status(400).body("{\"success\": false}");
        }
    }

    @PostMapping("/riderequests/reject")
    public ResponseEntity<?> rejectRideRequest(@RequestBody RideRequestDTO rideRequestDTO) {
        boolean success = rideService.rejectRideRequest(rideRequestDTO.getRideId());
        if (success) {
            return ResponseEntity.ok().body("{\"success\": true}");
        } else {
            return ResponseEntity.status(400).body("{\"success\": false}");
        }
    }

    @PostMapping("/bookride")
    public ResponseEntity<Ride> bookRide(@RequestBody Ride ride, @RequestParam String username) {
        return ResponseEntity.ok(rideService.bookRide(ride, username));
    }

    @GetMapping("/ridesbydate")
    public ResponseEntity<List<Ride>> getRidesByDate(@RequestParam("rideDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date rideDate) {
        List<Ride> rides = rideService.getRidesByDate(rideDate);
        return ResponseEntity.ok(rides);
    }

    @PostMapping("/fareestimate")
    public ResponseEntity<Map<String, Object>> getFareEstimate(@RequestBody Map<String, Object> fareRequest) {
        String vehicleType = (String) fareRequest.get("vehicleType");
        int distance = (int) fareRequest.get("distance");

        double farePerKm = vehicleType.equals("Luxury") ? 10:05;
        double totalFare = farePerKm * distance;

        Map<String, Object> response = new HashMap<>();
        response.put("fareEstimate", totalFare);
        response.put("farePerKm", farePerKm);
        response.put("vehicleType", vehicleType);
        response.put("distance", distance);

        return ResponseEntity.ok(response);
    }

    @PostMapping("/cancelride")
    public ResponseEntity<Map<String, Object>> cancelRide(@RequestBody Map<String, Long> request) {
        Long rideId = request.get("rideId");
        Map<String, Object> response = new HashMap<>();

        boolean success = rideService.cancelRide(rideId);
        response.put("success", success);

        return ResponseEntity.ok(response);
    }

    @GetMapping("/currentrides")
    public ResponseEntity<List<Ride>> getCurrentRides(@RequestParam String username) {
        List<Ride> rides = rideService.getRidesByUsername(username);
        return ResponseEntity.ok(rides);
    }

    @GetMapping("/riderequests/pending")
    public ResponseEntity<List<Ride>> getPendingRides() {
        List<Ride> rides = rideService.getPendingRides();
        return ResponseEntity.ok(rides);
    }

    
}
