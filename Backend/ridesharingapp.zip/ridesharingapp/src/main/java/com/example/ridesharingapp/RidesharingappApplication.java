package com.example.ridesharingapp;

import org.springframework.boot.
SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class RidesharingappApplication {

	public static void main(String[] args) {
		SpringApplication.run(RidesharingappApplication.class, args);
	}

}

