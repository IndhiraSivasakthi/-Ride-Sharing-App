package com.example.ridesharingapp.controller;

import com.example.ridesharingapp.model.RideFeedback;
import com.example.ridesharingapp.service.FeedbackService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/feedback")
public class FeedbackController {

    @Autowired
    private FeedbackService feedbackService;

    @PostMapping
    public ResponseEntity<String> submitFeedback(@RequestBody RideFeedback feedback) {
        try {
            boolean success = feedbackService.submitFeedback(feedback.getRating(), feedback.getFeedback());
            if (success) {
                return ResponseEntity.ok("Feedback submitted successfully");
            } else {
                return ResponseEntity.status(400).body("Failed to submit feedback");
            }
        } catch (Exception e) {
            return ResponseEntity.status(500).body("An error occurred: " + e.getMessage());
        }
    }
}
