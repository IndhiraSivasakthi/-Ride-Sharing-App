package com.example.ridesharingapp.service;

import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class DriverLogoutService {

    // This method should contain logic to record the logout time and username.
    public boolean recordLogout(String username, LocalDateTime logoutTime) {
        // Implement the logic to save logout details to the database or any other storage
        System.out.println("Driver: " + username + " logged out at: " + logoutTime);
        return true;  // Return true if successful
    }
}
