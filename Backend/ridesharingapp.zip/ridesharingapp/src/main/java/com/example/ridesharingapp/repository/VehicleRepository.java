package com.example.ridesharingapp.repository;

import com.example.ridesharingapp.model.Vehicle;
import org.springframework.data.jpa.repository.JpaRepository;

public interface VehicleRepository extends JpaRepository<Vehicle, Long> {
    // Custom query methods if needed
}
