package com.example.ridesharingapp.repository;

public class EarningsRepository {

}
