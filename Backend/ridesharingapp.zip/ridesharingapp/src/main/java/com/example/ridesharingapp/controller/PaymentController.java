package com.example.ridesharingapp.controller;

import com.example.ridesharingapp.model.Ride;
import com.example.ridesharingapp.service.PaymentService;
import com.example.ridesharingapp.service.RideService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class PaymentController {

    @Autowired
    private PaymentService paymentService;
    @Autowired
    private RideService rideService;
   

    @PostMapping("/processpayment")
    public ResponseEntity<?> processPayment(@RequestBody PaymentRequest paymentRequest) {
        boolean success = paymentService.processPayment(
                paymentRequest.getRideId(),
                paymentRequest.getAmount(),
                paymentRequest.getPaymentMethod()
        );

        if (success) {
            return ResponseEntity.ok().body("{\"success\": true}");
        } else {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("{\"success\": false}");
        }
    }

    // Inner class for request payload
    public static class PaymentRequest {
        private Long rideId;
        private Double amount;
        private String paymentMethod;

        // Getters and Setters

        public Long getRideId() {
            return rideId;
        }

        public void setRideId(Long rideId) {
            this.rideId = rideId;
        }

        public Double getAmount() {
            return amount;
        }

        public void setAmount(Double amount) {
            this.amount = amount;
        }

        public String getPaymentMethod() {
            return paymentMethod;
        }

        public void setPaymentMethod(String paymentMethod) {
            this.paymentMethod = paymentMethod;
        }
    }
}
