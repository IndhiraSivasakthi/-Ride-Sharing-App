package com.example.ridesharingapp.model;

public class Earnings {

}
